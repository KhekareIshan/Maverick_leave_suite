"use strict";
var express = require("express");
var router = express.Router();
var login = "false";
var db = require("../database");
var userdata;
let checklogin = "Not loggedin";
let users = db.query("SELECT * FROM users;", (err, result, fields) => {
  if (err) throw err;
  // console.log(JSON.stringify(result))
  // console.log(result)
  return result;
});
var checkpassword = "";
var checkusername = "";
var user_loggedin = "";
var loginresult = "";
var authenticated = "";

console.log(checkusername);
// router.get('/user-list', function(req, res, next) {
//     var sql='SELECT * FROM users';
//     db.query(sql, function (err, data, fields) {
//     if (err) throw err;
//     res.render('user-list', { title: 'User List', userData: data});
//   });
// });
/* GET home page. */

router.get("/", function (req, res, next) {
  var sql = `SELECT * FROM leaves WHERE issued_by = '${user_loggedin}'`;
  db.query(sql, function (err, data) {
    if (err) throw err;
    res.render("index", {
      title: "Maverick Leave System",
      checklogin: checklogin,
      user_loggedin: user_loggedin,
      leaves: data,
      login: login,
    });
  });
});
router.get("/change_password", function (req, res, next) {
  var sql = `SELECT * FROM users WHERE username = '${user_loggedin}'`;
  db.query(sql, function (err, data) {
    if (err) throw err;
    res.render("change_password", {
      title: "Change Password",
      checklogin: checklogin,
      user_loggedin: user_loggedin,
      users: data,
      login: login,
      authenticated: authenticated,
    });
  });
});
router.get("/issue_leave", function (req, res, next) {
  res.render("issue_leave", {
    title: "Maverick: Issue Leave",
    checklogin: checklogin,
    login: login,
  });
});
router.get("/view_leaves", function (req, res, next) {
  var sql = `SELECT * FROM leaves WHERE issued_by = '${user_loggedin}'`;
  db.query(sql, function (err, data) {
    if (err) throw err;
    res.render("view_leave", {
      title: "Maverick: view leave",
      checklogin: checklogin,
      user_loggedin: user_loggedin,
      leaves: data,
      login: login,
    });
  });
});
router.get("/view_all_leaves", function (req, res, next) {
  var sql = `SELECT * FROM leaves`;
  db.query(sql, function (err, data) {
    if (err) throw err;
    res.render("view_all_leave", {
      title: "Maverick: view all leave",
      checklogin: checklogin,
      user_loggedin: user_loggedin,
      leaves: data,
      login: login,
    });
  });
});
//Do not change

// router.get("/login", function (req, res, next) {
//   res.render("login", { title: "Maverick | Login" });
// });
router.get("/login", function (req, res, next) {
  var sql = "SELECT * FROM users";
  db.query(sql, function (err, data) {
    if (err) throw err;

    res.render("login", {
      title: "Maverick-Login",
      login: login,
      checkusername: checkusername,
      loginresult: loginresult,
      login: login,
      userData: data,
    });
  });
});

router.get("/redirecting", function (req, res, next) {
  var sql = "SELECT * FROM users";
  db.query(sql, function (err, data, fields) {
    if (err) throw err;

    res.render("redirect", {
      title: "Checking your credentials!!",
      checkpassword: checkpassword,
      checkusername: checkusername,
      userData: data,
    });
  });
});

router.get("/register", function (req, res, next) {
  var sql = "SELECT * FROM users";

  db.query(sql, function (err, data, fields) {
    if (err) throw err;
    let main_users = users;
    res.render("createaccount", {
      title: "Maverick-Register",
      userData: data,
      // main_users: main_users,
    });
  });
});
router.post("/register", (req, res) => {
  const username = req.body.user_name;
  const password = req.body.password;
  // for (var i = 0; i < users.length; i++) {
  //   console.log(i);
  // }
  var sql = `INSERT INTO users (username, password) VALUES ('${username}', '${password}')`;

  db.query(sql, function (err, data) {
    if (err) throw err;
    console.log("Record inserted");
    res.redirect("/login");
    console.log(users);
  });
  // console.log(users[i].username === username)
  // else {

  // }
  // res.send(users);
});
// console.log(users);
router.post("/login", (req, res) => {
  checklogin = "check!";
  console.log(checklogin);
  res.redirect("/");
});
router.post("/Redirect", (req, res) => {
  var password = req.body.password;
  var user_name = req.body.user_name;

  checkpassword = password;
  checkusername = user_name;
  console.log(checkpassword + " " + checkusername);
  res.redirect("/redirecting");
});
router.post("/logout", (req, res) => {
  login = "false";
  checklogin = "Not loggedin";
  user_loggedin = "";
  console.log(checklogin);
  res.redirect("/login");
});

router.post("/authenticated", (req, res) => {
  console.log(
    "authenticated " + username_used + " " + checkpassword + " " + checkusername
  );
  checkpassword = "";
  checkusername = "";
  loginresult = "";
  res.redirect("/");
});

router.post("/wronglogin", (req, res) => {
  var username_used = req.body.username2;

  console.log(
    "failed " + username_used + " " + checkpassword + " " + checkusername
  );
  checkpassword = "";
  checkusername = username_used;
  res.redirect("/login");
});
router.post("/", (req, res, next) => {
  let username = req.body.user_name;
  let password = req.body.password;
  let fetchQuery = "SELECT * FROM users;";
  db.query(fetchQuery, (err, data) => {
    if (err) throw err;
    users = data;
    console.log(users[0].username);
    for (let i = 0; i < users.length; i++) {
      if (username == users[i].username) {
        if (password == users[i].password) {
          user_loggedin = username;
          console.log("success");
          checklogin = "check!";
          loginresult = "";
          login = "true";
          res.redirect("/");
          return;
        } else {
          checklogin = "not_logged_in";
          login = "false";
          loginresult = "Wrong username or password!!";
          console.log("go home");
          res.redirect("/login");
          return;
        }
      } else {
        if (i == users.length) {
          checklogin = "not_logged_in";
          login = "false";
          loginresult = "Wrong username or password!!";
          console.log("go home");
          res.redirect("/login");
          return;
        }
      }
    }
  });
});
router.post("/change_password", (req, res, next) => {
  const username = req.body.user_name;
  const password = req.body.password;
  const real_password = req.body.real_password
  const password_new = req.body.password_new;
  const id = req.body.id;
      if (password == real_password) {
          console.log("success");
          var sql = `UPDATE users SET password = '${password_new}' WHERE id = '${id}'`;

          db.query(sql, function (err, data) {
            if (err) throw err;
            console.log("Password Changed");
            res.redirect("/");
            console.log(users);
          });
        } else {
          authenticated = "wrong password";
          console.log("go home");
          res.redirect("/change_password");
        }
});

router.post("/create_leave", (req, res) => {
  const leave_till = req.body.leave_till;
  const leave_from = req.body.leave_from;
  const type_of = req.body.type_of;
  const reason = req.body.reason;
  const todays_date = req.body.todays_date;
  const user_used = user_loggedin;
  // for (var i = 0; i < users.length; i++) {
  //   console.log(i);
  // }
  var sql = `INSERT INTO leaves (from_date, to_date, reason, date_issued, issued_by, type) VALUES ('${leave_from}', '${leave_till}', "${reason}", '${todays_date}', '${user_used}', '${type_of}')`;

  db.query(sql, function (err, data) {
    if (err) throw err;
    console.log("Record inserted");
    res.redirect("/");
    console.log(users);
  });
  // console.log(users[i].username === username)
  // else {

  // }
  // res.send(users);
});
router.post("/delete_leave", (req, res) => {
  const id = req.body.id;
  // for (var i = 0; i < users.length; i++) {
  //   console.log(i);
  // }
  var sql = `DELETE FROM leaves WHERE id='${id}'`;

  db.query(sql, function (err, data) {
    if (err) throw err;
    console.log("Record deleted");
    res.redirect("/view_leaves");
    console.log(users);
  });
  // console.log(users[i].username === username)
  // else {

  // }
  // res.send(users);
});
router.get('/about',(req,res,next) =>{
  var sql = `SELECT * FROM leaves WHERE issued_by = '${user_loggedin}'`;
  db.query(sql, function (err, data) {
    if (err) throw err;
    res.render("about", {
      title: "Maverick: About Us",
      checklogin: checklogin,
      user_loggedin: user_loggedin,
      leaves: data,
      login: login,
    });
  });
})
module.exports = router;
