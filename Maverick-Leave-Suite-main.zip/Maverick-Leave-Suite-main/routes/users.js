var express = require("express");
var router = express.Router();
var db = require("../database");

let users;

/* GET users listing. */
router.get("/", function (req, res, next) {
  res.send("go home");
});
router.post("/createaccount", function (req, res) {
  var username = req.body.user_name;
  var password = req.body.password;

  var sql = `INSERT INTO users (username, password) VALUES ('${username}', '${password}')`;

  db.query(sql, function (err, data) {
    if (err) throw err;
    console.log("Record inserted");
  });
  res.redirect("/login");
});

module.exports = router;
