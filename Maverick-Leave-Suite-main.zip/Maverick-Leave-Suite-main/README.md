<h1>In Development</h1>
<br>
<h2>
  This application will make life easier for small organizations who want to efficiently manage their employees leaves.
  Please support us by contributing to this project. Your contribution will mean a lot to us.
  Always welcome 😊.
