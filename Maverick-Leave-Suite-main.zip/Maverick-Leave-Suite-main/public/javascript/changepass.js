function checklogin() {
  var logincheck = document.getElementById("logincheck");
  console.log(logincheck);
  if (logincheck.value == "false") {
    console.log("right");
    window.location.href = "/login";
  } else {
    console.log("wrong");
  }
}
checklogin();
greet();
function openOffMenu() {
  document.querySelector(".off-menu").style.width = "350px";


}
function closeNav() {
  document.querySelector(".off-menu").style.width = "0px";

}
function change() {
  let eye = document.querySelector("#eye");
  let password = document.querySelector("#password");
  let password_new = document.querySelector("#password_new");
  if (password.type == "text") {
    password.type = "password";
    password_new.type = "password";
    eye.className = "fa fa-eye";
  } else {
    password.type = "text";
    password_new.type = "text";
    eye.className = "fa fa-eye-slash";
  }
}
