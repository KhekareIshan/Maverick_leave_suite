function checklogin() {
    var logincheck = document.getElementById("logincheck");
    console.log(logincheck);
    if (logincheck.value == "false") {
      console.log("right");
      window.location.href = "/login";
    } else {
      console.log("wrong");
    }
  }
  checklogin();
  function openOffMenu() {
    document.querySelector(".off-menu").style.width = "350px";
  
  
  }
  function closeNav() {
    document.querySelector(".off-menu").style.width = "0px";
  
  }