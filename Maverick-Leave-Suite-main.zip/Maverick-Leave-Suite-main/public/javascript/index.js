function greet() {
  var greeting = document.querySelector("#greeting-text");
  var user = document.querySelector("#user").value;
  let date = new Date().getHours();
  if (date >= 0 && date < 12) {
    greeting.textContent = "Good Morning " + user;
  } else if (date >= 12 && date < 18) {
    greeting.textContent = "Good Afternoon " + user;
  } else if (date >= 18) {
    greeting.textContent = "Good Evening " + user;
  }
}
function checklogin() {
  var logincheck = document.getElementById("logincheck");
  console.log(logincheck);
  if (logincheck.value == "false") {
    console.log("right");
    window.location.href = "/login";
  } else {
    console.log("wrong");
  }
}
checklogin();
greet();
function openOffMenu() {
  document.querySelector(".off-menu").style.width = "350px";


}
function closeNav() {
  document.querySelector(".off-menu").style.width = "0px";

}


function settingsPopup(){
  let settingsBtn = document.querySelector('.settings-button');
  let settingsDiv = document.querySelector('.settings-pop');
  if(settingsDiv.style.display == "none"){
    settingsDiv.style.display = "flex";
  }else {
    settingsDiv.style.display = "none"
  }

}