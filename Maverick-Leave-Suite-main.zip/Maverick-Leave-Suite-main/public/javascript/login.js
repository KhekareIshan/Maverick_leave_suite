const registerBtn = document.querySelector("#register-btn");
registerBtn.addEventListener("click", () => {
  window.location.href = "/register";
});
function change() {
  let eye = document.querySelector("#eye");
  let password = document.querySelector("#password");
  if (password.type == "text") {
    password.type = "password";
    eye.className = "fa fa-eye";
  } else {
    password.type = "text";
    eye.className = "fa fa-eye-slash";
  }
}
function checklogin() {
  var logincheck = document.getElementById("logincheck");
  console.log(logincheck)
  if (logincheck.value == "true") {
    console.log("right");
    window.location.href = "/";
  } else {
    console.log("wrong");
  }
}
function login() {
  try {
    var password = document.querySelector("#password").value;
    let username = document.querySelector("#user_name").value;
    // var users = document.querySelector('#data')
    var tr = document.getElementById(username);
    var td = tr.querySelectorAll("td");
    let form = document.querySelector("#loginform");
    console.log(username);
    console.log(password);
    console.log(tr);
    console.log(td[2].textContent);
    if (password == td[2].textContent) {
      console.log("success");
      alert("success");
      window.location.href = "/";
      form.submit();
    } else {
      alert("wrong password or username");
      window.location.href = "/login"
    }
  } catch (err) {
    alert("wrong username or password");
    window.location.href = "/login";
  }
}
eye.addEventListener("click", change());
change();
checklogin();