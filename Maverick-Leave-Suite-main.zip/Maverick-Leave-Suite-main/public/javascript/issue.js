function checklogin() {
  var logincheck = document.getElementById("logincheck").value;
  console.log(logincheck);
  if (logincheck == "false") {
    console.log("wrong");
    window.location.href = "/login";
  } else {
    console.log("right");
  }
}
checklogin();

let date = () => {
  let todayDate = new Date().getDate();
  let month = new Date().getMonth() + 1;
  let year = new Date().getFullYear();
  let dateInput = document.querySelector("#todaydate");
  dateInput.value = todayDate + "/" + month + "/" + year;
};
date();

// to verify dates
let leaveTill = document.querySelector("#leave-till");
leaveTill.addEventListener("change", verifyDate);

function verifyDate() {
  let submitBtn = document.querySelector("#submit-btn");
  let startLeave = document.querySelector("#leave-from");
  if (startLeave > leaveTill) {
  }
}

// // do not edit this
// var dates = {
//   convert : function(dt) {

//       return (
//           dt.constructor === Date ? dt :
//           dt.constructor === Array ? new Date(dt[0],dt[1],dt[2]) :
//           dt.constructor === Number ? new Date(dt) :
//           dt.constructor === String ? new Date(dt) :
//           typeof dt === "object" ? new Date(dt.year,dt.month,dt.date) :
//           NaN
//       );
//   },
//   compare : function(a,b) {

//       return (
//           isFinite(a=this.convert(a).valueOf()) &&
//           isFinite(b=this.convert(b).valueOf()) ?
//           (a>b)-(a<b) :
//           NaN
//       );
//   }
// }
// //

function compareDates() {
  //Get the text in the elements
  var from = document.getElementById("leave-from").value;
  var to = document.getElementById("leave-till").value;
  var fromDate = new Date(from);
  var toDate = new Date(to);
  let submitBtn = document.querySelector("#submit-btn");
  let message = document.querySelector("#message");
  fromDate.setHours(0, 0, 0, 0);
  toDate.setHours(0, 0, 0, 0);
  console.log("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh",fromDate);
  console.log(toDate);
  console.log(fromDate - toDate," (fromDate - toDate === 0)   ",  fromDate - toDate === 0);
  console.log((fromDate < toDate) || (fromDate - toDate === 0));
  if ((fromDate < toDate) || (fromDate - toDate === 0)) {
    submitBtn.disabled = false;
    console.log(submitBtn.disabled);
    console.log("correct");
    message.innerHTML = "";
  } else {
    submitBtn.disabled = "true";
    console.log(submitBtn.disabled);
    console.log("not_correct");
    message.innerHTML = "Please check the dates";
  }
}
compareDates();
