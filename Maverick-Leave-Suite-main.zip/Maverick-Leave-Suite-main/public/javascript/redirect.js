function login() {
  var password = document.getElementById("password").value;
  var username = document.getElementById("username").value;
  var data = document.getElementById("data");
  var tr = data.querySelectorAll('.hello');
  let form = document.getElementById("authenticated");
  let form2 = document.getElementById("wronglogin");
  console.log(username);
  console.log(password);
  console.log(data.innerHTML);
  console.log(tr);
  for(let i = 0; i < tr.length; i++){
    console.log(tr[i].lastElementChild)
  }
  // try {
  //   console.log(tr);
  //   // console.log(passwo  rd);
  //   // console.log(tr);
  //   console.log(td[1].innerHTML);
  //   if (password == td[2].innerHTML) {
  //     // alert("success");
  //     // window.location.href = "/";
  //     form.submit();
  //   } else {
  //     alert("wrong password or username");
  //     // window.location.href = "/login";
  //     form2.submit();
  //     // console.log(td[1].innerHTML)
  //   }
  // } catch (err) {
  //   // alert("wrong username or password");
  //   // window.location.href = '/'
  //   // form2.submit();
  //   wrong();
  // }
  var checkcredentials = ""
  for (let i = 0; i < tr.length; i++) {
    checkcredentials = ""
    var td = tr[i].querySelectorAll("td");
    console.log(td)
    console.log(td[2].innerHTML);
    console.log(tr[i]);
    if (tr[i].name = username) {
      console.log(td[2].innerHTML);
      console.log(tr[i]);
      if (td[2].innerHTML == password) {
        // form.submit();
        checkcredentials = "check"
      } else {
        // form2.submit();
      }
    }
  }
  if (checkcredentials == "check") {
    // form.submit();
    alert("success")
  } else {
    // form2.submit();
    alert("failure")
  }
}

function wrong() {
  let form2 = document.getElementById("wronglogin");
  form2.submit();
}
// login();
