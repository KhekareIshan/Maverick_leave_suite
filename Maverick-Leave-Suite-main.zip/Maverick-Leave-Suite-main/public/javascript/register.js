// const { disable } = require("debug");
window.onload = checkrepeatation;
function checkrepeatation() {
  let username = document.querySelector("#user_name");
  let password = document.querySelector("#password");
  let ul = document.getElementById("table");
  let li = ul.getElementsByTagName("li");
  let repeatation = 0;
  let submit_btn = document.querySelector("#submit-btn");
  let message = document.querySelector("#message");
  console.log(li[0]);
  console.log(username.value);

  for (let i = 0; i < li.length; i++) {
    if (li[i].innerHTML === username.value) {
      repeatation++;
    }
    // console.log(li[i].innerHTML);
    // console.log(li[i].innerHTML === username.value)
    console.log(username.value);
    console.log(repeatation);
  }
  if (
    repeatation > 0 ||
    username.value.length == null ||
    password.value.length < 8
  ) {
    disable(repeatation);
    console.log("disabled");
    // console.log(submit_btn.disabled)
  } else {
    enable();
    console.log("enabled");
    // console.log(submit_btn.disabled)
  }
}
function disable(rep) {
  let username = document.querySelector("#user_name");
  let password = document.querySelector("#password");
  let submit_btn = document.querySelector("#submit-btn");
  let message = document.querySelector("#message");
  submit_btn.disabled = "True";
  if (rep > 0) {
    message.innerHTML = "Username already in use";
    console.log("exist");
  } else if (username.value == "") {
    message.innerHTML = "";
    console.log("null");
  } /*if(username.value.length < 8) {
        message.innerHTML = "username must be atleast 8 characters"
    } else*/ else if (password.value == "") {
    message.innerHTML = "";
    console.log("pass null");
  } else if (password.value.length < 8) {
    message.innerHTML = "password must be atlest 8 charcters";
    console.log("<8");
  } else {
    console.log("hello");
  }
  console.log(password.value.length);
  console.log("button disabled");
  console.log(username.value);
  console.log(submit_btn.disabled);
}
function enable() {
  let submit_btn = document.querySelector("#submit-btn");
  let message = document.querySelector("#message");
  submit_btn.disabled = "";
  message.innerHTML = "";
  console.log("button enabled");
  console.log(submit_btn.disabled);
}
function change() {
  let eye = document.querySelector("#eye");
  let password = document.querySelector("#password");
  if (password.type == "text") {
    password.type = "password";
    eye.className = "fa fa-eye";
  } else {
    password.type = "text";
    eye.className = "fa fa-eye-slash";
  }
}
